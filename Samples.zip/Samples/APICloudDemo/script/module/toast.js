/*示例简介:
toast 提示;
 */

/* toast */
api.toast({
    msg: "APICloud 重新定义移动开发",
    duration: 1000,
    location: "middle"
});