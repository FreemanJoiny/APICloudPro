/*
 播放网络视频;
 */

api.openVideo(
    {
        url: "http://resource.apicloud.com/video/apicloud3.mp4"
    }
);
